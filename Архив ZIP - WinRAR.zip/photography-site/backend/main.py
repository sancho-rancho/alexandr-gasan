from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from pathlib import Path
import os

app = FastAPI()

# CORS для разработки
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Пути
BASE_DIR = Path(__file__).parent
FRONTEND_DIR = BASE_DIR.parent / "frontend"
STATIC_DIR = BASE_DIR / "static"

# Создаем папки если их нет
(STATIC_DIR / "home").mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "about").mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "prices").mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "gallery" / "street").mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "gallery" / "portrait").mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "gallery" / "cars").mkdir(parents=True, exist_ok=True)

# Статика фронтенда
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
app.mount("/assets", StaticFiles(directory=FRONTEND_DIR), name="assets")

def get_images(folder: str):
    folder_path = STATIC_DIR / folder
    images = []
    if folder_path.exists():
        for file in folder_path.iterdir():
            if file.suffix.lower() in ['.jpg', '.jpeg', '.png', '.webp']:
                images.append(f"/static/{folder}/{file.name}")
    return images

@app.get("/api/images/{category}")
async def get_images_api(category: str):
    if category == "gallery":
        return {
            "categories": {
                "street": get_images("gallery/street"),
                "portrait": get_images("gallery/portrait"),
                "cars": get_images("gallery/cars")
            }
        }
    return {"images": get_images(category)}

# Отдаем фронтенд
@app.get("/")
async def serve_frontend():
    return FileResponse(FRONTEND_DIR / "index.html")

@app.get("/{path:path}")
async def serve_frontend_path(path: str):
    file_path = FRONTEND_DIR / path
    if file_path.exists():
        return FileResponse(file_path)
    return FileResponse(FRONTEND_DIR / "index.html")


# Удалите этот дубликат (оставьте только один экземпляр)
@app.get("/api/images/gallery/{category}")
async def get_gallery_category(category: str):
    valid_categories = ["street", "portrait", "cars"]
    if category not in valid_categories:
        raise HTTPException(status_code=404, detail="Category not found")
    return {"images": get_images(f"gallery/{category}")}



from fastapi.responses import JSONResponse

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail}
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)