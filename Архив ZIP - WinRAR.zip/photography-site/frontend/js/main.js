// Конфигурация
const API_BASE_URL = window.location.origin;

// Состояние приложения
let currentPage = 'home';
let isLoading = false;

// Инициализация приложения
function initApp() {
    // Устанавливаем начальную страницу
    const initialPage = getPageFromHash();
    navigateTo(initialPage, false);
    
    // Настройка навигации
    setupNavigation();
    
    // Добавляем обработчик кликов по контенту
    document.addEventListener('click', handleContentClicks);
}

// Настройка навигации
function setupNavigation() {
    // Обработчики для ссылок меню
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            if (page !== currentPage && !isLoading) {
                navigateTo(page);
            }
        });
    });
}

// Обработка кликов внутри контента
function handleContentClicks(e) {
    // Кнопка галереи на главной
    if (e.target.classList.contains('gallery-btn')) {
        e.preventDefault();
        navigateTo('gallery');
    }
    
    // Категории в галерее
    if (e.target.closest('.gallery-category')) {
        e.preventDefault();
        const category = e.target.closest('.gallery-category').getAttribute('data-category');
        openCategoryModal(category);
    }
    
    // Закрытие модального окна
    if (e.target.classList.contains('close-modal')) {
        document.querySelector('.modal')?.remove();
    }
}

// Навигация
function navigateTo(page, updateHash = true) {
    if (isLoading) return;
    
    isLoading = true;
    currentPage = page;
    
    // Обновляем hash если нужно
    if (updateHash) {
        window.location.hash = page;
    }
    
    // Обновляем UI
    updateNavLinks();
    updatePageTitle(page);
    
    // Загружаем страницу
    loadPage(page);
}

function getPageFromHash() {
    const hash = window.location.hash.substring(1);
    return ['home', 'about', 'prices', 'gallery'].includes(hash) ? hash : 'home';
}

function updateNavLinks() {
    document.querySelectorAll('.nav-link').forEach(link => {
        const linkPage = link.getAttribute('data-page');
        if (linkPage === currentPage) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

function updatePageTitle(page) {
    const titles = {
        home: 'Главная',
        about: 'Обо мне',
        prices: 'Цены',
        gallery: 'Альбом'
    };
    document.title = `Фотограф | ${titles[page]}`;
}

// Загрузка страниц
async function loadPage(page) {
    try {
        // Показываем лоадер
        document.getElementById('content').innerHTML = '<div class="loader">Загрузка...</div>';
        
        // Загрузка данных
        const endpoint = page === 'gallery' ? 'gallery' : page;
        const response = await fetch(`${API_BASE_URL}/api/images/${endpoint}`);
        
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        
        const data = await response.json();
        console.log('Loaded data for', page, data);
        
        // Генерация HTML
        let html;
        switch(page) {
            case 'home':
                html = createHomePage(data.images || []);
                break;
            case 'about':
                html = createAboutPage(data.images || []);
                break;
            case 'prices':
                html = createPricesPage(data.images || []);
                break;
            case 'gallery':
                html = createGalleryPage(data.categories || {});
                break;
            default:
                html = createHomePage([]);
        }
        
        document.getElementById('content').innerHTML = html;
        
        
    } catch (error) {
        console.error('Ошибка загрузки:', error);
        showErrorPage(error);
    } finally {
        isLoading = false;
    }
}

// Генераторы страниц
function createHomePage(images) {
    const heroImage = images[0] || 'https://via.placeholder.com/1200x800/000000/FFFFFF/?text=Photography';
    
    return `
        <div class="page home-page active">
            <img src="${heroImage}" alt="Hero image" class="hero-image">
            <div class="welcome-content">
                <h1 class="welcome-text">Добро пожаловать</h1>
                <button class="gallery-btn">Посмотреть галерею</button>
            </div>
        </div>
    `;
}

function createAboutPage(images) {
    const defaultImage = 'https://via.placeholder.com/600x400/000000/FFFFFF/?text=About+Me';
    
    return `
        <div class="page about-page active">
            <div class="about-container">
                <div class="about-text">
                    <p>Я профессиональный фотограф с многолетним опытом. Специализируюсь на авто-фотографии и портретах.</p>
                    <p>Моя цель - запечатлеть моменты, которые рассказывают истории.</p>
                </div>
                <div class="about-images">
                    ${images.length > 0 
                        ? images.map(img => `<img src="${img}" alt="About me">`).join('') 
                        : `<img src="${defaultImage}" alt="About me">`
                    }
                </div>
            </div>
        </div>
    `;
}

function createPricesPage(images) {
    const defaultImage = 'https://via.placeholder.com/400x300/000000/FFFFFF/?text=Price';
    
    return `
        <div class="page prices-page active">
            <div class="price-list">
                <div class="price-item">
                    <img src="${images[0] || defaultImage}" alt="Индивидуальная фотосессия">
                    <h3>Индивидуальная фотосессия</h3>
                    <p>1000 руб/час</p>
                    <ul>
                        <li>Подготовка концепции</li>
                        <li>До 100 обработанных фото</li>
                        <li>Срок сдачи - 3 дня</li>
                    </ul>
                </div>
                <div class="price-item">
                    <img src="${images[1] || defaultImage}" alt="Свадебная съёмка">
                    <h3>Свадебная съёмка</h3>
                    <p>от 10000 руб</p>
                    <ul>
                        <li>Полный день съёмки</li>
                        <li>200+ обработанных фото</li>
                        <li>Срок сдачи - 7 дней</li>
                    </ul>
                </div>
                <div class="price-item">
                    <img src="${images[2] || defaultImage}" alt="Авто фотосессия">
                    <h3>Авто фотосессия</h3>
                    <p>500 руб/час</p>
                    <ul>
                        <li>3 локации на выбор</li>
                        <li>50+ обработанных фото</li>
                        <li>Срок сдачи - 2 дня</li>
                    </ul>
                </div>
                <div class="price-item">
                    <img src="${images[3] || defaultImage}" alt="Репортажная съёмка">
                    <h3>Репортажная съёмка</h3>
                    <p>от 2000 руб</p>
                    <ul>
                        <li>3 часа съёмки</li>
                        <li>100+ обработанных фото</li>
                        <li>Оперативная цветокоррекция</li>
                        <li>Срок сдачи - до 2 дней</li>
                    </ul>
                </div>
            </div>
        </div>
    `;
}

function createGalleryPage(categories) {
    const defaultCategories = {
        street: ['https://via.placeholder.com/600x400/000000/FFFFFF/?text=Street'],
        portrait: ['https://via.placeholder.com/600x400/000000/FFFFFF/?text=Portrait'],
        cars: ['https://via.placeholder.com/600x400/000000/FFFFFF/?text=Cars']
    };
    
    const cats = Object.keys(categories).length > 0 ? categories : defaultCategories;
    
    return `
        <div class="page gallery-page active">
            <div class="gallery-grid">
                ${Object.entries(cats).map(([category, images]) => `
                    <div class="gallery-category" data-category="${category}">
                        <img src="${images[0] || 'https://via.placeholder.com/600x400'}" alt="${category}">
                        <div class="category-title">${category.charAt(0).toUpperCase() + category.slice(1)}</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

async function getCategoryImages(category) {
    const response = await fetch(`${API_BASE_URL}/api/images/gallery`);
    const data = await response.json();
    return data.categories[category] || [];
}

async function openCategoryModal(category) {
    try {
        const images = await getCategoryImages(category);
        
        const modalHtml = `
            <div class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title">${category.charAt(0).toUpperCase() + category.slice(1)}</h2>
                        <span class="close-modal"></span>
                    </div>
                    <div class="modal-images-container">
                        <div class="modal-images">
                            ${images.map(img => `
                                <img src="${img}" alt="${category} photo" loading="lazy">
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        // Показываем модалку с анимацией
        setTimeout(() => {
            document.querySelector('.modal').classList.add('active');
        }, 10);
        
        // Обработчики закрытия
        document.querySelector('.close-modal').addEventListener('click', closeModal);
        document.querySelector('.modal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
        
        // Закрытие по ESC
        document.addEventListener('keydown', function escClose(e) {
            if (e.key === 'Escape') {
                closeModal();
                document.removeEventListener('keydown', escClose);
            }
        });
        
    } catch (error) {
        console.error('Error opening modal:', error);
        alert(`Не удалось загрузить категорию "${category}": ${error.message}`);
    }
}

function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.remove();
        }, 300); // Ждем завершения анимации
    }
}


function showErrorPage(error) {
    document.getElementById('content').innerHTML = `
        <div class="error-page">
            <h1>Ошибка</h1>
            <p>${error.message || 'Неизвестная ошибка'}</p>
            <button onclick="navigateTo('home')">На главную</button>
        </div>
    `;
}

document.addEventListener('DOMContentLoaded', initApp);